One or more textures on this 3D-model have been created with images from Textures.com.
These images may not be redistributed by default. Please visit www.textures.com for more information.
This applies for all assets in this package, see asset store license for more information. (Appendix 2.2)

Trees in Mobile/Normal edited Folder use sphere shaped normals.
Use ambient occlusion trees for terrains.